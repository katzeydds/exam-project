package com.example.tests;

import com.example.pages.LoginPage;
import com.example.pages.SearchRecordPage;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class SearchIrasasPos4 {

    private WebDriver driver;
    private LoginPage loginPage;
    private SearchRecordPage searchRecordPage;

    @Before
    public void setUp() {
        System.setProperty("webdriver.gecko.driver", "C:\\Users\\Vartotojas\\Desktop\\Geckodriver\\geckodriver.exe");
        driver = new FirefoxDriver();
        loginPage = new LoginPage(driver);
        searchRecordPage = new SearchRecordPage(driver);
    }

    @Test
    public void testSearchRecord() {
        loginPage.openLoginPage();
        loginPage.enterUsername("new_user");
        loginPage.enterPassword("password123");
        loginPage.clickLoginButton();

        searchRecordPage.goToAtliktosOperacijos();

        String expectedResult = "19";
        searchRecordPage.clickRodytiForExpectedResult(expectedResult);

    }

    @After
    public void tearDown() throws InterruptedException {
        Thread.sleep(5000);

        if (driver != null) {
            driver.quit();
        }
    }
}

