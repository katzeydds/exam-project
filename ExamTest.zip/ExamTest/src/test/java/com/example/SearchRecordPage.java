package com.example.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SearchRecordPage {

    private WebDriver driver;
    private WebDriverWait wait;

    public SearchRecordPage(WebDriver driver) {
        this.driver = driver;
        wait = new WebDriverWait(driver, 10);
    }

    public void enterUsername(String username) {
        WebElement usernameField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("username")));
        usernameField.sendKeys(username);
    }

    public void enterPassword(String password) {
        WebElement passwordField = driver.findElement(By.name("password"));
        passwordField.sendKeys(password);
    }

    public void clickLoginButton() {
        WebElement loginButton = driver.findElement(By.cssSelector(".btn-primary"));
        loginButton.click();
    }

    public void goToAtliktosOperacijos() {
        WebElement atliktosOperacijosButton = wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Atliktos operacijos")));
        atliktosOperacijosButton.click();
    }

    public void clickRodytiForExpectedResult(String expectedResult) {
        WebElement resultRow = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//td[text()='" + expectedResult + "']")));
        WebElement rodytiButton = resultRow.findElement(By.xpath("./following-sibling::td/a[contains(@href, '/rodyti?id=')]"));
        rodytiButton.click();
    }
}
