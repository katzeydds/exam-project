package com.example.tests;

import com.example.pages.LoginPage;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import static org.junit.Assert.assertTrue;

public class TestLoginPos2 {

    private WebDriver driver;
    private LoginPage loginPage;

    @Before
    public void setUp() {
        System.setProperty("webdriver.gecko.driver", "C:\\Users\\Vartotojas\\Desktop\\Geckodriver\\geckodriver.exe");
        driver = new FirefoxDriver();
        loginPage = new LoginPage(driver);
    }

    @Test
    public void testLoginPositive() {
        loginPage.openLoginPage();
        loginPage.enterUsername("new_user");
        loginPage.enterPassword("password123");
        loginPage.clickLoginButton();

        assertTrue(loginPage.isLoginSuccessful());
    }

    @After
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
