package com.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class RegistrationPage {

    private WebDriver driver;
    private WebDriverWait wait;

    public RegistrationPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, 10);
    }

    public void openRegistrationPage() {
        driver.get("http://localhost:8080/prisijungti");
    }

    public void clickCreateAccountLink() {
        WebElement createAccountLink = wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Sukurti naują paskyrą")));
        createAccountLink.click();
    }

    public void enterUsername(String username) {
        WebElement usernameField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("username")));
        usernameField.sendKeys(username);
    }

    public void enterPassword(String password) {
        WebElement passwordField = driver.findElement(By.id("password"));
        passwordField.sendKeys(password);
    }

    public void enterPasswordConfirm(String passwordConfirm) {
        WebElement passwordConfirmField = driver.findElement(By.id("passwordConfirm"));
        passwordConfirmField.sendKeys(passwordConfirm);
    }

    public void clickCreateButton() {
        WebElement createButton = driver.findElement(By.cssSelector(".btn-primary"));
        createButton.click();
    }

    public boolean isRegistrationSuccessful() {
        return driver.getCurrentUrl().contains("success");
    }

    public boolean isErrorMessageDisplayed() {
        try {
            WebElement errorMessage = driver.findElement(By.className("error-message"));
            return errorMessage.isDisplayed();
        } catch (org.openqa.selenium.NoSuchElementException e) {
            return false;
        }
    }
}
