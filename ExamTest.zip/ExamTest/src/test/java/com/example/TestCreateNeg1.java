package com.example;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import static org.junit.Assert.assertTrue;

public class TestCreateNeg1 {

    private WebDriver driver;
    private RegistrationPage registrationPage;

    @Before
    public void setUp() {
        System.setProperty("webdriver.gecko.driver", "C:\\Users\\Vartotojas\\Desktop\\Geckodriver\\geckodriver.exe");
        driver = new FirefoxDriver();
        registrationPage = new RegistrationPage(driver);
        registrationPage.openRegistrationPage();
    }

    @Test
    public void testNegativeLoginAndCreateAccount() {
        registrationPage.clickCreateAccountLink();
        registrationPage.enterUsername("ffs");
        registrationPage.enterPassword("o");
        registrationPage.enterPasswordConfirm("jjj");
        registrationPage.clickCreateButton();

        assertTrue(registrationPage.isErrorMessageDisplayed());
    }


    @After
    public void tearDown() throws InterruptedException {
        Thread.sleep(5000);

        if (driver != null) {
            driver.quit();
        }
    }
}