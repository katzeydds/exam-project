import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TestCreateIrasas3 {

    private WebDriver driver;

    @Before
    public void setUp() {
        System.setProperty("webdriver.gecko.driver", "C:\\Users\\Vartotojas\\Desktop\\Geckodriver\\geckodriver.exe");
        driver = new FirefoxDriver();
    }

    @Test
    public void testCreateRecord() throws InterruptedException {
        driver.get("http://localhost:8080/prisijungti");

        try {
            WebDriverWait wait = new WebDriverWait(driver, 10);

            WebElement usernameField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("username")));
            usernameField.sendKeys("new_user");

            WebElement passwordField = driver.findElement(By.name("password"));
            passwordField.sendKeys("password123");

            WebElement loginButton = driver.findElement(By.cssSelector(".btn-primary"));
            loginButton.click();

            Thread.sleep(1000);

            WebElement linkSk1 = wait.until(ExpectedConditions.elementToBeClickable(By.id("sk1")));
            linkSk1.click();

            WebElement inputSk1 = driver.findElement(By.id("sk1"));
            inputSk1.clear();
            inputSk1.sendKeys("10");

            WebElement linkSk2 = driver.findElement(By.id("sk2"));
            linkSk2.click();

            WebElement inputSk2 = driver.findElement(By.id("sk2"));
            inputSk2.clear();
            inputSk2.sendKeys("9");

            WebElement operationDropdown = driver.findElement(By.name("zenklas"));
            operationDropdown.sendKeys("-");

            Thread.sleep(1000);

            WebElement calculateButton = driver.findElement(By.cssSelector("input[type='submit'][value='skaičiuoti']"));
            calculateButton.click();

            Thread.sleep(5000);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @After
    public void tearDown() throws InterruptedException {
        Thread.sleep(5000);

        if (driver != null) {
            driver.quit();
        }
    }
}
