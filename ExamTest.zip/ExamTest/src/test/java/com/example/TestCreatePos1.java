package com.example;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import static org.junit.Assert.assertTrue;

public class TestCreatePos1 {

    private WebDriver driver;
    private RegistrationPage registrationPage;

    @Before
    public void setUp() {
        System.setProperty("webdriver.gecko.driver", "C:\\Users\\Vartotojas\\Desktop\\Geckodriver\\geckodriver.exe");
        driver = new FirefoxDriver();
        registrationPage = new RegistrationPage(driver);
        registrationPage.openRegistrationPage();
    }

    @Test
    public void testPositiveLoginAndCreateAccount() {
        registrationPage.clickCreateAccountLink();
        registrationPage.enterUsername("new_user");
        registrationPage.enterPassword("password123");
        registrationPage.enterPasswordConfirm("password123");
        registrationPage.clickCreateButton();

        assertTrue(registrationPage.isRegistrationSuccessful());
    }

    @After
    public void tearDown() throws InterruptedException {
        Thread.sleep(5000);

        if (driver != null) {
            driver.quit();
        }
    }
}
