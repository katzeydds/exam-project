package com.example.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class CreateRecordPage {
    private WebDriver driver;

    public CreateRecordPage(WebDriver driver) {
        this.driver = driver;
    }

    public void enterSk1(String sk1) {
        WebElement sk1Field = driver.findElement(By.id("sk1"));
        sk1Field.clear();
        sk1Field.sendKeys(sk1);
    }

    public void enterSk2(String sk2) {
        WebElement sk2Field = driver.findElement(By.id("sk2"));
        sk2Field.clear();
        sk2Field.sendKeys(sk2);
    }

    public void selectOperation(String operation) {
        WebElement operationDropdown = driver.findElement(By.name("zenklas"));
        Select select = new Select(operationDropdown);
        select.selectByValue(operation);
    }

    public void clickCalculateButton() {
        WebElement calculateButton = driver.findElement(By.cssSelector("input[type='submit'][value='skaičiuoti']"));
        calculateButton.click();
    }

    public boolean isErrorDisplayed() {
        try {
            WebElement errorElement = driver.findElement(By.id("error-message"));
            return errorElement.isDisplayed();
        } catch (org.openqa.selenium.NoSuchElementException e) {
            return false;
        }
    }
}
