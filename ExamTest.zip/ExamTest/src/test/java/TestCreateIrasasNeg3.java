package com.example.tests;

import com.example.pages.CreateRecordPage;
import com.example.pages.LoginPage;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import static org.junit.Assert.assertTrue;

public class TestCreateIrasasNeg3 {

    private WebDriver driver;
    private LoginPage loginPage;
    private CreateRecordPage createRecordPage;

    @Before
    public void setUp() {
        System.setProperty("webdriver.gecko.driver", "C:\\Users\\Vartotojas\\Desktop\\Geckodriver\\geckodriver.exe");
        driver = new FirefoxDriver();
        loginPage = new LoginPage(driver);
        createRecordPage = new CreateRecordPage(driver);
    }

    @Test
    public void testCreateRecordNegative() {
        loginPage.openLoginPage();
        loginPage.enterUsername("new_user");
        loginPage.enterPassword("password123");
        loginPage.clickLoginButton();

        createRecordPage.enterSk1("1");
        createRecordPage.enterSk2("0");
        createRecordPage.selectOperation("/");

        createRecordPage.clickCalculateButton();

        assertTrue(createRecordPage.isErrorDisplayed());
    }

    @After
    public void tearDown() throws InterruptedException {
        Thread.sleep(5000);

        if (driver != null) {
            driver.quit();
        }
    }
}
